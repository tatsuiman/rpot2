:doc:`broxygen </scripts/broxygen/index>`

   This package is loaded during the process which automatically generates
   reference documentation for all Bro scripts (i.e. "Broxygen").  Its only
   purpose is to provide an easy way to load all known Bro scripts plus any
   extra scripts needed or used by the documentation process.

